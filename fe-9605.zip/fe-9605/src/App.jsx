import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import Form from './Components/Form/Form'

function App() {

  return (
    <>
<Form/>
    </>
  )
}

export default App
